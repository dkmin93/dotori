package day03;

public class YouJin extends Person { //상속 받는 자녀클래스를 만들경우
	
	public YouJin() { //자녀클래스의 생성자가 없더라도 자동으로 생성된다
		super("유진");
	}
	

}
