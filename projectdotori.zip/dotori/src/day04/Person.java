package day04;

public class Person {
	
	private int age = 10;
	
	//setter를 활용해서 age를 변경하기
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public int getAge() {
		return age;
	}

}
