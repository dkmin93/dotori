package day05;

public interface Printed {
	
	void print (String doc);
	int copy (int i);
	

}
