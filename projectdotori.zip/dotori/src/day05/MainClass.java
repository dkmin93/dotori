package day05;

public class MainClass {
	
	public static void main(String[] args) {
		
		Printed p1 = new LG();
		Printed p2 = new Samsung();
		
		p1.print("도토리가루로만든모수의시그니처도토리국수");
		p1.copy(3); 
		
		
	}

}
