package day01;

public class Example05 {

	public static void main(String[] args) {

		boolean result = hello(2);
		
		

}
	static boolean hello(int a) {
		return a % 2 == 0? true : false;	
	}
	
	
}
