package day01;

public class Student {
	
	public String name;


}
