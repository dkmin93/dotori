package day01;

public class Note {
	
	public static void main(String[] args) {
		
		
	}

}

class Solution {
    public String solution(String str1, String str2) {
        String answer = "";
        return answer;
    }
}
