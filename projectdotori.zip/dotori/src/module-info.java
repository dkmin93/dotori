/**
 * 
 */
/**
 * 
 */
module dotori {
}